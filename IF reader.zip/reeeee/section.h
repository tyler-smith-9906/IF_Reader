#ifndef SECTION_H
#define SECTION_H

#include <string>
#include "ifinterpreter.h"

using namespace std;

class Section
{
    private:
        string text;
    public:
        Section(string str) : text(str) {};
        void execute(IFInterpreter* ins);
        string getText(){return text;};

};

#endif