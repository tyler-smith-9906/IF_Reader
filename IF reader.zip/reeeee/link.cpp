#include <string>

#include "link.h"

Link::Link(const string& str):Section(str)
{

    int pos = str.find("-&gt");
    if(pos == -1)
    {
        displayText = str.substr(2,str.size()-4);
        linkPassage = displayText;
    }
    else
    {
        displayText = str.substr(2,str.size()-pos+1);
        linkPassage = str.substr(pos+5,str.size()-pos-7);  
    }
    
}

void Link::execute(IFInterpreter* ins)
{

    ins->setPos(ins->pIndex[linkPassage]);
}

string Link::getText()
{
    return displayText;
}

string Link::getPassage()
{
    return linkPassage;
}