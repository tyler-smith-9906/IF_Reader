#include <string>

#include "set.h"

Set::Set(string str):Section(str)
{
    string temp;

    int pos = str.find("$");
    for(int i = pos + 1; str[i] != ' '; i++)
        variableName += str[i];
    
    pos = str.find("to ");
    for(int i = pos + 3; i < str.size()-1;i++)
        temp += str[i];
    if(temp == "true")
        value = true;
    else
        value = false;
    
}

void Set::execute(IFInterpreter* ins)
{
    if(ins->variables.find(variableName) == ins->variables.end())   
        ins->variables.emplace(variableName,value);
    else
        ins->variables[variableName] = value;
    
}

string Set::getVar()
{
    return variableName;
}

bool Set::getVal()
{
    return value;
}