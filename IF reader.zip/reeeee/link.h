#ifndef LINK_H
#define LINK_H

#include "section.h"

class Interpreter;
class Link : public Section
{
    private:
        string displayText;
        string linkPassage;
    public:
        Link(const string& str);
        void execute(IFInterpreter* ins);
        string getPassage();
        string getText();

};
#endif