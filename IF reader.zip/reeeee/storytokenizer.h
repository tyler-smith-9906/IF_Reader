#ifndef __STORYTOKENIZER_H
#define __STORYTOKENIZER_H
#include <string>
#include <unordered_map>
#include "ifinterpreter.h"
using namespace std;
//Easier to reference these strings when making them constants
const string BLOCK_S = "[";
const string BLOCK_E = "]";
const string ELSEIF_S = "(else-if:";
const string GOTO_S = "(go-to:";
const string SET_S = "(set:";
const string IF_S = "(if:";
const string ELSE_S = "(else:";
const string LINK_S = "[[";
const string LINK_E = "]]";
const string COMMAND_E = ")";
const string PASS_N = "name=";//if i broke somthing it here

//Token types
enum token_t{LINK,GOTO,SET,IF,ELSEIF,ELSE,BLOCK,TEXT,PASS};//if i broke del pass

class PartToken
{
    private:
        string text;
        token_t type;
    public:
        PartToken(){};
        PartToken(const string& str):text(str), type(TEXT){};
        PartToken(const string& str1, token_t t):text(str1), type(t){};
        const string& getText()
        {
            return text;
        }
        token_t getType()
        {
            return type;
        }
};

class PassageTokenizer
{
    private:
        string passage;
        unsigned int pos;
        token_t last;
    public:
        PassageTokenizer(){};
        PassageTokenizer(const string& str):passage(str), pos(0), last(TEXT) {};
        PartToken nextPart()
        {
            //Creates object of a token to return
            PartToken get;
            //If the position in the text is over the size return the invalid type and empty object
            if(pos>=passage.size())
            {
                last = TEXT;
                return get;
            }
            //Creates a position to reference with first block starter
            unsigned int pos1 = passage.find(BLOCK_S, pos);
            unsigned int ending;
            //If the last token had else.if.elseif types and the pos is npos
            if((last == ELSEIF || last == ELSE || last == IF) && pos1 != string::npos)
            {
                ending = pos1+1;
                //control flag activated
                int control = 1;
                while(control>0 && ending <passage.size())
                {
                    if(passage.substr(ending, BLOCK_S.size()) == BLOCK_S)
                        control++;
                    else if(passage.substr(ending, BLOCK_S.size()) == BLOCK_E)
                        control--;
                    ending++;
                }
            

                if(control = 0)
                    last = BLOCK;
                else
                    last = TEXT;
                get = PartToken(passage.substr(pos1, ending - pos1), BLOCK);
                pos = ending;
                return get;
            }
            else
            {
                //creates positions for each of the next tokens to find
                unsigned int posSet = passage.find(SET_S, pos);
                unsigned int posGo = passage.find(GOTO_S, pos);
                unsigned int posLink = passage.find(LINK_S, pos);
                unsigned int posIf = passage.find(IF_S, pos);
                unsigned int posElseIf = passage.find(ELSEIF_S, pos);
                unsigned int posElse = passage.find(ELSE_S, pos);
                //Orders them to find next immediate 
                unsigned int posGet = posSet;
                if(posGo<posGet)
                    posGet = posGo;
                if(posGo<posGet)
                    posGet = posGo;
                if(posLink<posGet)
                    posGet = posLink;
                if(posIf<posGet)
                    posGet = posIf;
                if(posElseIf<posGet)
                    posGet=posElseIf;
                if(posElse<posGet)
                    posGet=posElse;
                ending = -1;
                last = TEXT;
                if(posGet>pos)
                {
                    ending = posGet;
                }
                else if(posGet==posLink)
                {
                    ending = passage.find(LINK_E, posLink) + LINK_E.size();
                    last = LINK;
                }
                else if(posGet != string::npos)
                {
                    ending = passage.find(COMMAND_E,pos) + 1;
                    if(posGet == posGo)
                        last = GOTO;
                    else if(posGet == posSet)
                        last = SET;
                    else if(posGet == posElseIf)
                        last = ELSEIF;
                    else if(posGet == posElse)
                        last = ELSE;
                    else if(posGet == posIf)
                        last = IF;
                    else
                        last = TEXT;
                }

                if(ending!=string::npos)
                    get = PartToken(passage.substr(pos, ending-pos), last);
                else
                    get = PartToken(passage.substr(pos), last);
                pos = ending;
                return get;
            }
        }
        bool hasNextPart()
        {
            return pos<passage.size();
        }
        
};
class PassageToken
{
    private:
        string text;
        string name;
    public:
        PassageToken(){};
        PassageToken(const string& str):text(str){};
        PassageToken(const string& t, const string& n):name(t), text(n){};
        string getName()
        {
            return name;
        }
        string getText()
        {
            return text;
        }
};

class StoryTokenizer
{
    private:
      string story;
      unsigned int pos;

    public:
        //Initializes the class with a nullptr and empty string and empty position
        StoryTokenizer(const string& st):story(st), pos(0) {};
        //Functions
        PassageToken nextPassage() 
        { 
            int pos1 = story.find("<tw-passagedata", pos);
            int pos2 = story.find(">", pos1) + 1;
            int pos3 = story.find("</tw-passagedata>", pos2);

            if(pos2 == string::npos || pos3 == string::npos)
            {
                return PassageToken();
            }
            else
                pos = pos3;
                int beginName = story.find("name=\"", pos1) + 7;
                int endName = story.find("\"", beginName);

                if(beginName == string::npos || endName == string::npos)
                {
                    return PassageToken(story.substr(pos1, pos3-pos1));
                }
                else
                    return PassageToken(story.substr(beginName-1, endName - beginName+1), story.substr(pos2, pos3-pos2));
        }

        bool hasNextPassage() const
        {
            return story.find("<tw-passagedata", pos) != string::npos;
        }
};

#endif