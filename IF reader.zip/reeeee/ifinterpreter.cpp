#include <iostream>
#include <fstream>
#include <unordered_map>

#include <queue>
#include "ifinterpreter.h"
#include "storytokenizer.h"

#include "goto.h"
#include "ifs.h"
#include "link.h"
#include "set.h"
#include "text.h"
#include "section.h"

using namespace std;

IFInterpreter::IFInterpreter(const string& file)
{
    string st, line;
    string filename = file;
    ifstream in(filename);            

    if (!in.is_open())
    {
        cout << "Couldn't open " << filename << " for reading!\n";
        //break;
    }
    //Read in the story from input.txt
    getline(in, line);
    while (in && line != "</html>")
    {
        st += line + '\n';
        getline(in, line);
    }
    //Construct the StoryTokenizer object
    StoryTokenizer story(st);
    while(story.hasNextPassage())
    {
        PassageToken passage = story.nextPassage();
        pIndex.emplace(passage.getName(),passages.size());
        passages.push_back(passage);
    }            
    goLink=0;
}

void IFInterpreter::play()
{
    int finished = 0; //allows 1 more pass through once at the end of the game
	

    while(finished == 0) //loops while through passages while remaining within bounds
    {
       
		goLink = 0;
		goGoto = 0;
		links.clear();

        queue<Ifs> ifBlocks;//queue used to store each if statement block. queue in order to follow first in first out 

        PassageTokenizer ptok(passages[pos].getText()); //uses the passage vector for the tokenizer
		
		
        while(ptok.hasNextPart())
        {
			
			
			PartToken stok(ptok.nextPart());
			
            //checks if the current section is an if/elseif/else and finds its block
			if (stok.getType() == IF || stok.getType() == ELSEIF || stok.getType() == ELSE)
			{
				string copy = stok.getText();
				stok = ptok.nextPart();
				Ifs ifs(copy, stok.getText());
				ifBlocks.push(ifs);

				stok = ptok.nextPart();
                //if there are any elseif/else related to the previous if statement, that gets added to the queue as well
				while (stok.getType() == ELSE || stok.getType() == ELSEIF)
				{
					copy = stok.getText();

					stok = ptok.nextPart();

					Ifs extra(copy, stok.getText());						
					ifBlocks.push(extra);

				}
				
				
                while(!ifBlocks.empty())
                {
                    ifBlocks.front().execute(this);//executes the front if statement
                    
                    if(ifBlocks.front().getCompleted() == 1)//if that executes properly, removes the other elseifs or else from the queue
                    {
                        while(!ifBlocks.empty())
                            ifBlocks.pop();
                    }
                    else
                    {
                        ifBlocks.pop();
                    }
                }


				if (stok.getType() == SET)
				{
					Set st(stok.getText());
					st.execute(this);
				}
				else if (stok.getType() == TEXT)
				{
					Text tx(stok.getText());
					tx.execute(this);
				}
				else if (stok.getType() == LINK)
				{
					Link* link = new Link(stok.getText());
					cout << link->getText();
					links.push_back(link);

					goLink = 1;
				}
				else if (stok.getType() == GOTO)
				{
					Goto gt(stok.getText());
					gt.execute(this);
					goGoto = 1;
					break;
				}

				if (goGoto == 1)
					break;


            }
            else if(stok.getType() == SET)
            {
                Set st(stok.getText());
                st.execute(this);
            }
            else if(stok.getType() == TEXT)
            {
                Text tx(stok.getText());
                tx.execute(this);
            }
            else if(stok.getType() == LINK)
            {
                Link* link = new Link(stok.getText());
				cout << link->getText();
                links.push_back(link);
				
                goLink = 1;
            }
            else if(stok.getType() == GOTO)
            {
                Goto gt(stok.getText());
                gt.execute(this);
				goGoto = 1;
                break;
            }

			if (goGoto == 1)
				break;
        }

		//Ends Program if passage with no Links or Gotos is ran
		if ((goLink == 0) && (goGoto == 0))
			finished = 1;

        if(goLink == 1)
        {
			int choicecount = 0;
			cout << "\n"<< endl;
			
			for (int i = 0; i < links.size(); i++) //prints ll the link choices
			{
				cout << i + 1 << ". " << links[i]->getText() << endl;
				choicecount++;
			}
            int choice;
			cin >> choice;
			
			while (!cin || choice < 1 || choice > choicecount) //takes user input for the passage they want to go to
			{
				cout << "Invalid Choice, Re-enter a number between 1 and " << choicecount << ": ";
				cin.clear();
				cin.ignore(10000, '\n');
				cin >> choice;
			}
            
			links[choice - 1]->execute(this);//moves to the passage that the user selected
			
        }

    }
}