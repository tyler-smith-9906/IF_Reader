#ifndef GOTO_H
#define GOTO_H

#include "section.h"

class Goto : public Section
{
    private:
        string gopassage;
    public:
        Goto(string str);
        void execute(IFInterpreter* insert);
        string getPassage();


};

#endif