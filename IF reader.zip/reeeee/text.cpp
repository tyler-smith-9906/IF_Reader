#include "text.h"

Text::Text(string str):Section(str)
{}

void Text::execute(IFInterpreter* ins)
{
    cout << getText();
}