#ifndef _IFINTERPRETER_H
#define _IFINTERPRETER_H

#include <iostream>
#include <vector>
#include <unordered_map>
#include "storytokenizer.h"
using namespace std;
class Link;
class IFInterpreter
{
    private:
        int pos = 0;
    public:
        unordered_map<string,int> pIndex;
        unordered_map<string,bool> variables;
        vector<PassageToken> passages;
		vector<Link*> links;
        IFInterpreter(const string& file);
        void play();
		int goLink;
		int goGoto;
        int getPos() {return pos;};
        void setPos(int x) {pos = x;};

};
#endif