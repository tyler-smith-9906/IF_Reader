#ifndef SET_H
#define SET_H

#include "section.h"

class Set : public Section
{
    private:
        string variableName;
        bool value;
    public:
        Set(string str);
        void execute(IFInterpreter* ins);
        string getVar();
        bool getVal();
};
#endif