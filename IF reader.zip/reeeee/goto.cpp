#include <string>

#include "goto.h"

Goto::Goto(string str):Section(str)
{	
	int pos = str.find("&quot;");
	for (int i = pos + 6; str[i] != '&'; i++)
	{
		gopassage += str[i];
	}

}

void Goto::execute(IFInterpreter* insert)
{
	insert->setPos(insert->pIndex[gopassage]);
}


string Goto::getPassage()
{
	return gopassage;
}